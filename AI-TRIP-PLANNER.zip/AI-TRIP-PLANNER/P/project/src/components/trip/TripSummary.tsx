import React from 'react';
import { Link } from 'react-router-dom';
import { useTrip, TripPlan } from '../../context/TripContext';
import { MapPin, Calendar, DollarSign, Users, Home, MapIcon, ArrowRight, Star } from 'lucide-react';

const TripSummary: React.FC = () => {
  const { tripPlan, loading } = useTrip();
  
  if (loading) {
    return (
      <div className="w-full flex flex-col items-center justify-center py-12">
        <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-indigo-500 mb-4"></div>
        <h3 className="text-xl font-semibold text-gray-800">Generating your perfect trip...</h3>
        <p className="text-gray-600 mt-2">We're creating a tailored itinerary just for you</p>
      </div>
    );
  }
  
  if (!tripPlan) {
    return (
      <div className="w-full flex flex-col items-center justify-center py-12">
        <div className="text-center">
          <h3 className="text-xl font-semibold text-gray-800 mb-2">No trip plan generated yet</h3>
          <p className="text-gray-600 mb-6">Please select a destination and set your preferences</p>
          <Link
            to="/planner"
            className="inline-flex items-center px-6 py-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors"
          >
            Start Planning
          </Link>
        </div>
      </div>
    );
  }
  
  const formatCost = (cost: number) => {
    return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(cost);
  };
  
  const formatDate = (dateString: string) => {
    const options: Intl.DateTimeFormatOptions = { weekday: 'short', month: 'short', day: 'numeric' };
    return new Date(dateString).toLocaleDateString('en-US', options);
  };

  return (
    <div className="w-full max-w-4xl mx-auto p-4">
      {/* Trip Overview Card */}
      <div className="bg-white rounded-xl shadow-lg overflow-hidden mb-8">
        <div className="relative h-48 md:h-64 bg-gradient-to-r from-indigo-500 to-purple-600">
          <div className="absolute inset-0 opacity-30 bg-[url('https://images.pexels.com/photos/1051073/pexels-photo-1051073.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2')] bg-cover bg-center"></div>
          <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-end">
            <div className="p-6 sm:p-8">
              <div className="flex items-center mb-2">
                <MapPin size={20} className="text-white mr-2" />
                <h2 className="text-2xl sm:text-3xl font-bold text-white">{tripPlan.destination}</h2>
              </div>
              <div className="flex flex-wrap gap-y-2 gap-x-4 text-white">
                <div className="flex items-center">
                  <Calendar size={16} className="mr-1" />
                  <span>{tripPlan.startDate && tripPlan.endDate ? 
                    `${formatDate(tripPlan.startDate)} - ${formatDate(tripPlan.endDate)}` : 
                    '5 days'}
                  </span>
                </div>
                <div className="flex items-center">
                  <DollarSign size={16} className="mr-1" />
                  <span className="capitalize">{tripPlan.budget} Budget</span>
                </div>
                <div className="flex items-center">
                  <Users size={16} className="mr-1" />
                  <span className="capitalize">{tripPlan.groupType} Trip</span>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <div className="p-6 sm:p-8">
          <div className="mb-6">
            <h3 className="text-xl font-semibold text-gray-800 mb-2">Trip Summary</h3>
            <p className="text-gray-600">
              We've created a personalized {tripPlan.itinerary.length}-day itinerary for your {tripPlan.groupType} trip to {tripPlan.destination} with a {tripPlan.budget} budget.
            </p>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
            <div className="bg-indigo-50 rounded-lg p-4">
              <div className="flex items-center mb-2">
                <Home size={18} className="text-indigo-600 mr-2" />
                <h4 className="font-semibold text-gray-800">Accommodations</h4>
              </div>
              <p className="text-gray-600">{tripPlan.hotels.length} hotels selected</p>
            </div>
            
            <div className="bg-indigo-50 rounded-lg p-4">
              <div className="flex items-center mb-2">
                <MapIcon size={18} className="text-indigo-600 mr-2" />
                <h4 className="font-semibold text-gray-800">Activities</h4>
              </div>
              <p className="text-gray-600">
                {tripPlan.itinerary.reduce((sum, day) => sum + day.attractions.length, 0)} attractions to visit
              </p>
            </div>
            
            <div className="bg-indigo-50 rounded-lg p-4">
              <div className="flex items-center mb-2">
                <DollarSign size={18} className="text-indigo-600 mr-2" />
                <h4 className="font-semibold text-gray-800">Total Cost</h4>
              </div>
              <p className="text-indigo-700 font-medium">{formatCost(tripPlan.totalCost)}</p>
            </div>
          </div>
          
          <Link
            to="/itinerary"
            className="w-full sm:w-auto inline-flex items-center justify-center px-6 py-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors"
          >
            View Full Itinerary
            <ArrowRight size={20} className="ml-2" />
          </Link>
        </div>
      </div>
      
      {/* Recommended Hotels Preview */}
      <div className="mb-8">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-xl font-semibold text-gray-800">Recommended Hotels</h3>
          <Link to="/itinerary" className="text-indigo-600 hover:text-indigo-800 transition-colors">
            View all
          </Link>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {tripPlan.hotels.slice(0, 3).map((hotel) => (
            <div key={hotel.id} className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-all duration-300">
              <div className="h-40 overflow-hidden">
                <img 
                  src={hotel.image} 
                  alt={hotel.name} 
                  className="w-full h-full object-cover transition-transform duration-500 hover:scale-110"
                />
              </div>
              <div className="p-4">
                <h4 className="font-semibold text-gray-800 mb-1">{hotel.name}</h4>
                <div className="flex items-center mb-2">
                  {Array.from({ length: Math.floor(hotel.rating) }).map((_, i) => (
                    <Star key={i} size={14} className="text-yellow-400 fill-current" />
                  ))}
                  {hotel.rating % 1 !== 0 && (
                    <div className="relative">
                      <Star size={14} className="text-gray-300 fill-current" />
                      <div className="absolute top-0 left-0 overflow-hidden" style={{ width: `${(hotel.rating % 1) * 100}%` }}>
                        <Star size={14} className="text-yellow-400 fill-current" />
                      </div>
                    </div>
                  )}
                  <span className="text-sm text-gray-600 ml-1">{hotel.rating.toFixed(1)}</span>
                </div>
                <p className="text-sm text-gray-600 line-clamp-2 mb-2">{hotel.description}</p>
                <div className="flex justify-between items-center">
                  <span className="text-indigo-700 font-semibold">{formatCost(hotel.pricePerNight)} / night</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
      
      {/* Trip Highlights */}
      <div>
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-xl font-semibold text-gray-800">Trip Highlights</h3>
          <Link to="/itinerary" className="text-indigo-600 hover:text-indigo-800 transition-colors">
            See full itinerary
          </Link>
        </div>
        
        <div className="bg-white rounded-xl shadow-md p-6">
          <div className="space-y-4">
            {tripPlan.itinerary.slice(0, 3).map((day) => (
              <div key={day.day} className="flex items-start">
                <div className="bg-indigo-100 text-indigo-800 font-semibold rounded-full h-8 w-8 flex items-center justify-center shrink-0 mt-1">
                  {day.day}
                </div>
                <div className="ml-4">
                  <h4 className="font-semibold text-gray-800">Day {day.day}</h4>
                  <ul className="mt-1 space-y-1">
                    {day.attractions.map((attraction) => (
                      <li key={attraction.id} className="text-gray-600 flex items-center">
                        <span className="w-2 h-2 bg-indigo-400 rounded-full mr-2"></span>
                        {attraction.name} ({attraction.duration})
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            ))}
          </div>
          
          {tripPlan.itinerary.length > 3 && (
            <div className="mt-4 pt-4 border-t border-gray-100 text-center">
              <Link 
                to="/itinerary" 
                className="text-indigo-600 hover:text-indigo-800 transition-colors"
              >
                + {tripPlan.itinerary.length - 3} more days
              </Link>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default TripSummary;
import React, { useState, useEffect } from 'react';
import { useTrip } from '../../context/TripContext';
import { Search, MapPin } from 'lucide-react';

interface Destination {
  id: string;
  name: string;
  image: string;
  description: string;
}

const popularDestinations: Destination[] = [
  {
    id: '1',
    name: 'Paris, France',
    image: 'https://images.pexels.com/photos/699466/pexels-photo-699466.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    description: 'The City of Light, known for its art, fashion, and cuisine.'
  },
  {
    id: '2',
    name: 'Tokyo, Japan',
    image: 'https://images.pexels.com/photos/2506923/pexels-photo-2506923.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    description: 'A vibrant metropolis blending tradition and cutting-edge technology.'
  },
  {
    id: '3',
    name: 'New York City, USA',
    image: 'https://images.pexels.com/photos/802024/pexels-photo-802024.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    description: 'The Big Apple, a hub of culture, arts, and entertainment.'
  },
  {
    id: '4',
    name: 'Rome, Italy',
    image: 'https://images.pexels.com/photos/532263/pexels-photo-532263.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    description: 'The Eternal City, rich in history and architectural wonders.'
  },
  {
    id: '5',
    name: 'Bali, Indonesia',
    image: 'https://images.pexels.com/photos/1098365/pexels-photo-1098365.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    description: 'A tropical paradise with lush landscapes and spiritual culture.'
  },
  {
    id: '6',
    name: 'Kyoto, Japan',
    image: 'https://images.pexels.com/photos/1440476/pexels-photo-1440476.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    description: 'A city of ancient temples, traditional gardens, and rich culture.'
  }
];

const DestinationSelector: React.FC = () => {
  const { destination, setDestination, setStep } = useTrip();
  const [searchTerm, setSearchTerm] = useState('');
  const [searchResults, setSearchResults] = useState<Destination[]>([]);
  const [selectedDestination, setSelectedDestination] = useState<Destination | null>(null);
  
  useEffect(() => {
    if (searchTerm.trim() === '') {
      setSearchResults([]);
      return;
    }
    
    // Filter destinations based on search term
    const results = popularDestinations.filter(
      dest => dest.name.toLowerCase().includes(searchTerm.toLowerCase())
    );
    setSearchResults(results);
  }, [searchTerm]);
  
  const handleDestinationSelect = (dest: Destination) => {
    setSelectedDestination(dest);
    setDestination(dest.name);
    setSearchTerm('');
    setSearchResults([]);
  };
  
  const handleCustomDestination = () => {
    if (searchTerm.trim() !== '') {
      setDestination(searchTerm);
      setSearchTerm('');
      setSearchResults([]);
    }
  };

  const handleContinue = () => {
    setStep(2);
  };

  return (
    <div className="w-full max-w-4xl mx-auto p-4">
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-gray-800 mb-2">Where would you like to go?</h2>
        <p className="text-gray-600">Search for a destination or select from popular choices</p>
      </div>
      
      {/* Search Box */}
      <div className="mb-8 relative">
        <div className="relative">
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search for a destination..."
            className="w-full px-4 py-3 pl-10 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all duration-200"
          />
          <Search size={20} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
        </div>
        
        {searchResults.length > 0 && (
          <div className="absolute z-10 w-full mt-1 bg-white shadow-lg rounded-lg border border-gray-200 max-h-60 overflow-y-auto">
            {searchResults.map((dest) => (
              <div
                key={dest.id}
                className="px-4 py-3 hover:bg-indigo-50 cursor-pointer flex items-center"
                onClick={() => handleDestinationSelect(dest)}
              >
                <MapPin size={16} className="text-indigo-500 mr-2" />
                <span>{dest.name}</span>
              </div>
            ))}
          </div>
        )}
        
        {searchTerm && searchResults.length === 0 && (
          <div className="absolute z-10 w-full mt-1 bg-white shadow-lg rounded-lg border border-gray-200">
            <div
              className="px-4 py-3 hover:bg-indigo-50 cursor-pointer flex items-center"
              onClick={handleCustomDestination}
            >
              <MapPin size={16} className="text-indigo-500 mr-2" />
              <span>Use "{searchTerm}" as destination</span>
            </div>
          </div>
        )}
      </div>
      
      {/* Selected Destination Card */}
      {destination && (
        <div className="mb-8 bg-white rounded-xl shadow-lg overflow-hidden transition-all duration-300 hover:shadow-xl transform hover:-translate-y-1">
          <div className="relative h-48">
            <img
              src={selectedDestination?.image || "https://images.pexels.com/photos/1051073/pexels-photo-1051073.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"}
              alt={destination}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-end">
              <div className="p-6">
                <h3 className="text-2xl font-bold text-white">{destination}</h3>
                <p className="text-white/90">Selected destination</p>
              </div>
            </div>
          </div>
          <div className="p-6">
            <p className="text-gray-700">
              {selectedDestination?.description || "Your dream destination for an unforgettable journey."}
            </p>
            <button
              onClick={handleContinue}
              className="mt-4 w-full bg-indigo-600 text-white py-3 px-4 rounded-lg hover:bg-indigo-700 transition-colors"
            >
              Continue with this destination
            </button>
          </div>
        </div>
      )}
      
      {/* Popular Destinations */}
      <div>
        <h3 className="text-xl font-semibold text-gray-800 mb-4">Popular Destinations</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {popularDestinations.map(dest => (
            <div
              key={dest.id}
              onClick={() => handleDestinationSelect(dest)}
              className="bg-white rounded-lg overflow-hidden shadow-md hover:shadow-xl transition-all duration-300 cursor-pointer transform hover:-translate-y-1"
            >
              <div className="relative h-48">
                <img
                  src={dest.image}
                  alt={dest.name}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end">
                  <div className="p-4">
                    <h4 className="text-lg font-semibold text-white">{dest.name}</h4>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default DestinationSelector;
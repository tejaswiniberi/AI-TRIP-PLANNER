import React, { useState } from 'react';
import { useTrip, TripPlan, Hotel } from '../../context/TripContext';
import { Calendar, Clock, DollarSign, MapPin, Star, Heart, Share2, Printer } from 'lucide-react';

const ItineraryDetail: React.FC = () => {
  const { tripPlan } = useTrip();
  const [activeTab, setActiveTab] = useState<'itinerary' | 'accommodations' | 'summary'>('itinerary');
  const [selectedHotel, setSelectedHotel] = useState<Hotel | null>(null);
  
  if (!tripPlan) {
    return (
      <div className="w-full flex flex-col items-center justify-center py-12">
        <div className="text-center">
          <h3 className="text-xl font-semibold text-gray-800 mb-2">No trip plan available</h3>
          <p className="text-gray-600 mb-6">Please create a trip plan first</p>
          <a
            href="/planner"
            className="inline-flex items-center px-6 py-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors"
          >
            Create Trip Plan
          </a>
        </div>
      </div>
    );
  }
  
  const formatCost = (cost: number) => {
    return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(cost);
  };
  
  const totalDays = tripPlan.itinerary.length;
  const totalAttractions = tripPlan.itinerary.reduce((total, day) => total + day.attractions.length, 0);
  
  return (
    <div className="w-full max-w-6xl mx-auto p-4">
      {/* Header */}
      <div className="bg-white rounded-xl shadow-lg overflow-hidden mb-6">
        <div className="relative h-64 bg-gradient-to-r from-indigo-500 to-purple-600">
          <div className="absolute inset-0 opacity-30 bg-[url('https://images.pexels.com/photos/1051073/pexels-photo-1051073.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2')] bg-cover bg-center"></div>
          <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-end">
            <div className="p-8">
              <div className="flex items-center mb-2">
                <MapPin size={20} className="text-white mr-2" />
                <h1 className="text-3xl font-bold text-white">{tripPlan.destination}</h1>
              </div>
              <p className="text-white/90 text-lg">
                {totalDays} days • {totalAttractions} attractions • {tripPlan.budget} budget
              </p>
            </div>
          </div>
        </div>
        
        <div className="p-6">
          <div className="flex flex-wrap justify-between items-center">
            <div className="flex items-center text-gray-700 mb-4 md:mb-0">
              <Calendar size={18} className="mr-1" />
              <span>
                {tripPlan.startDate && tripPlan.endDate 
                  ? `${new Date(tripPlan.startDate).toLocaleDateString()} - ${new Date(tripPlan.endDate).toLocaleDateString()}`
                  : `${totalDays} day trip`}
              </span>
            </div>
            
            <div className="flex space-x-2">
              <button className="flex items-center px-4 py-2 rounded-lg border border-gray-300 text-gray-700 hover:bg-gray-50 transition-colors">
                <Heart size={18} className="mr-1" />
                <span className="hidden sm:inline">Save</span>
              </button>
              <button className="flex items-center px-4 py-2 rounded-lg border border-gray-300 text-gray-700 hover:bg-gray-50 transition-colors">
                <Share2 size={18} className="mr-1" />
                <span className="hidden sm:inline">Share</span>
              </button>
              <button className="flex items-center px-4 py-2 rounded-lg border border-gray-300 text-gray-700 hover:bg-gray-50 transition-colors">
                <Printer size={18} className="mr-1" />
                <span className="hidden sm:inline">Print</span>
              </button>
            </div>
          </div>
        </div>
      </div>
      
      {/* Tabs */}
      <div className="bg-white rounded-xl shadow-md mb-6">
        <div className="flex overflow-x-auto">
          <button
            onClick={() => setActiveTab('itinerary')}
            className={`px-6 py-4 font-medium text-sm flex-shrink-0 ${
              activeTab === 'itinerary'
                ? 'border-b-2 border-indigo-600 text-indigo-600'
                : 'text-gray-500 hover:text-gray-700'
            }`}
          >
            Daily Itinerary
          </button>
          <button
            onClick={() => setActiveTab('accommodations')}
            className={`px-6 py-4 font-medium text-sm flex-shrink-0 ${
              activeTab === 'accommodations'
                ? 'border-b-2 border-indigo-600 text-indigo-600'
                : 'text-gray-500 hover:text-gray-700'
            }`}
          >
            Accommodations
          </button>
          <button
            onClick={() => setActiveTab('summary')}
            className={`px-6 py-4 font-medium text-sm flex-shrink-0 ${
              activeTab === 'summary'
                ? 'border-b-2 border-indigo-600 text-indigo-600'
                : 'text-gray-500 hover:text-gray-700'
            }`}
          >
            Cost Summary
          </button>
        </div>
      </div>
      
      {/* Tab Content */}
      <div className="bg-white rounded-xl shadow-lg p-6">
        {/* Itinerary Tab */}
        {activeTab === 'itinerary' && (
          <div>
            <h2 className="text-2xl font-bold text-gray-800 mb-6">Your {totalDays}-Day Itinerary</h2>
            
            <div className="space-y-8">
              {tripPlan.itinerary.map((day) => (
                <div key={day.day} className="border-b border-gray-100 pb-8 last:border-0">
                  <h3 className="text-xl font-semibold text-indigo-700 mb-4">Day {day.day}</h3>
                  
                  <div className="space-y-6">
                    {/* Morning */}
                    <div>
                      <div className="flex items-center mb-3">
                        <div className="h-8 w-8 rounded-full bg-yellow-100 flex items-center justify-center mr-2">
                          <span className="text-yellow-600">AM</span>
                        </div>
                        <h4 className="font-medium text-gray-800">Morning</h4>
                      </div>
                      
                      <div className="pl-10">
                        <div className="p-4 bg-yellow-50 rounded-lg mb-3">
                          <p className="text-sm text-gray-600">
                            <span className="font-medium">Breakfast:</span> {day.meals.breakfast}
                          </p>
                        </div>
                        
                        {day.attractions[0] && (
                          <div className="bg-white rounded-lg border border-gray-200 overflow-hidden hover:shadow-md transition-all duration-300">
                            <div className="sm:flex">
                              <div className="h-40 sm:h-auto sm:w-40 flex-shrink-0">
                                <img 
                                  src={day.attractions[0].image} 
                                  alt={day.attractions[0].name} 
                                  className="w-full h-full object-cover"
                                />
                              </div>
                              <div className="p-4">
                                <div className="flex items-center justify-between mb-1">
                                  <h5 className="font-semibold text-gray-800">{day.attractions[0].name}</h5>
                                  <span className="text-indigo-600 font-medium">{formatCost(day.attractions[0].cost)}</span>
                                </div>
                                <div className="flex items-center text-sm text-gray-500 mb-2">
                                  <Clock size={14} className="mr-1" />
                                  <span>{day.attractions[0].duration}</span>
                                </div>
                                <p className="text-gray-600 text-sm">{day.attractions[0].description}</p>
                              </div>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                    
                    {/* Afternoon */}
                    <div>
                      <div className="flex items-center mb-3">
                        <div className="h-8 w-8 rounded-full bg-blue-100 flex items-center justify-center mr-2">
                          <span className="text-blue-600">PM</span>
                        </div>
                        <h4 className="font-medium text-gray-800">Afternoon</h4>
                      </div>
                      
                      <div className="pl-10">
                        <div className="p-4 bg-blue-50 rounded-lg mb-3">
                          <p className="text-sm text-gray-600">
                            <span className="font-medium">Lunch:</span> {day.meals.lunch}
                          </p>
                        </div>
                        
                        {day.attractions[1] && (
                          <div className="bg-white rounded-lg border border-gray-200 overflow-hidden hover:shadow-md transition-all duration-300">
                            <div className="sm:flex">
                              <div className="h-40 sm:h-auto sm:w-40 flex-shrink-0">
                                <img 
                                  src={day.attractions[1].image} 
                                  alt={day.attractions[1].name} 
                                  className="w-full h-full object-cover"
                                />
                              </div>
                              <div className="p-4">
                                <div className="flex items-center justify-between mb-1">
                                  <h5 className="font-semibold text-gray-800">{day.attractions[1].name}</h5>
                                  <span className="text-indigo-600 font-medium">{formatCost(day.attractions[1].cost)}</span>
                                </div>
                                <div className="flex items-center text-sm text-gray-500 mb-2">
                                  <Clock size={14} className="mr-1" />
                                  <span>{day.attractions[1].duration}</span>
                                </div>
                                <p className="text-gray-600 text-sm">{day.attractions[1].description}</p>
                              </div>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                    
                    {/* Evening */}
                    <div>
                      <div className="flex items-center mb-3">
                        <div className="h-8 w-8 rounded-full bg-purple-100 flex items-center justify-center mr-2">
                          <span className="text-purple-600">EVE</span>
                        </div>
                        <h4 className="font-medium text-gray-800">Evening</h4>
                      </div>
                      
                      <div className="pl-10">
                        <div className="p-4 bg-purple-50 rounded-lg mb-3">
                          <p className="text-sm text-gray-600">
                            <span className="font-medium">Dinner:</span> {day.meals.dinner}
                          </p>
                        </div>
                        
                        {day.attractions[2] && (
                          <div className="bg-white rounded-lg border border-gray-200 overflow-hidden hover:shadow-md transition-all duration-300">
                            <div className="sm:flex">
                              <div className="h-40 sm:h-auto sm:w-40 flex-shrink-0">
                                <img 
                                  src={day.attractions[2].image} 
                                  alt={day.attractions[2].name} 
                                  className="w-full h-full object-cover"
                                />
                              </div>
                              <div className="p-4">
                                <div className="flex items-center justify-between mb-1">
                                  <h5 className="font-semibold text-gray-800">{day.attractions[2].name}</h5>
                                  <span className="text-indigo-600 font-medium">{formatCost(day.attractions[2].cost)}</span>
                                </div>
                                <div className="flex items-center text-sm text-gray-500 mb-2">
                                  <Clock size={14} className="mr-1" />
                                  <span>{day.attractions[2].duration}</span>
                                </div>
                                <p className="text-gray-600 text-sm">{day.attractions[2].description}</p>
                              </div>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                    
                    {/* Transportation */}
                    <div className="pl-10 mt-4">
                      <div className="p-4 bg-gray-50 rounded-lg border border-gray-200">
                        <p className="text-sm text-gray-600">
                          <span className="font-medium">Transportation:</span> {day.transportation}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
        
        {/* Accommodations Tab */}
        {activeTab === 'accommodations' && (
          <div>
            <h2 className="text-2xl font-bold text-gray-800 mb-6">Recommended Hotels</h2>
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {tripPlan.hotels.map((hotel) => (
                <div 
                  key={hotel.id} 
                  className={`bg-white rounded-lg overflow-hidden transition-all duration-300 ${
                    selectedHotel?.id === hotel.id 
                      ? 'ring-2 ring-indigo-500 shadow-lg' 
                      : 'border border-gray-200 hover:shadow-md'
                  }`}
                  onClick={() => setSelectedHotel(hotel)}
                >
                  <div className="h-48 overflow-hidden">
                    <img 
                      src={hotel.image} 
                      alt={hotel.name} 
                      className="w-full h-full object-cover transition-transform duration-500 hover:scale-110"
                    />
                  </div>
                  <div className="p-4">
                    <div className="flex justify-between items-start mb-2">
                      <h3 className="font-semibold text-gray-800 text-lg">{hotel.name}</h3>
                      <span className="bg-indigo-100 text-indigo-800 text-sm font-medium px-2.5 py-0.5 rounded-full">
                        {formatCost(hotel.pricePerNight)} / night
                      </span>
                    </div>
                    
                    <div className="flex items-center mb-3">
                      {Array.from({ length: Math.floor(hotel.rating) }).map((_, i) => (
                        <Star key={i} size={16} className="text-yellow-400 fill-current" />
                      ))}
                      {hotel.rating % 1 !== 0 && (
                        <div className="relative">
                          <Star size={16} className="text-gray-300 fill-current" />
                          <div className="absolute top-0 left-0 overflow-hidden" style={{ width: `${(hotel.rating % 1) * 100}%` }}>
                            <Star size={16} className="text-yellow-400 fill-current" />
                          </div>
                        </div>
                      )}
                      <span className="text-sm text-gray-600 ml-1">{hotel.rating.toFixed(1)}</span>
                    </div>
                    
                    <p className="text-gray-600 mb-4">{hotel.description}</p>
                    
                    <div className="flex flex-wrap gap-2 mb-4">
                      {hotel.amenities.map((amenity, index) => (
                        <span key={index} className="text-xs bg-gray-100 text-gray-800 px-2 py-1 rounded">
                          {amenity}
                        </span>
                      ))}
                    </div>
                    
                    <div className="flex justify-between items-center">
                      <button className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors">
                        Select
                      </button>
                      
                      <button className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors">
                        More info
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
        
        {/* Cost Summary Tab */}
        {activeTab === 'summary' && (
          <div>
            <h2 className="text-2xl font-bold text-gray-800 mb-6">Trip Cost Breakdown</h2>
            
            <div className="bg-indigo-50 rounded-xl p-6 mb-8">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-semibold text-gray-800">Total Trip Cost</h3>
                <span className="text-2xl font-bold text-indigo-700">{formatCost(tripPlan.totalCost)}</span>
              </div>
              
              <p className="text-gray-600 text-sm">
                This is an estimated cost based on your preferences for a {tripPlan.groupType} trip with a {tripPlan.budget} budget.
                Actual costs may vary depending on booking timing, availability, and other factors.
              </p>
            </div>
            
            <div className="space-y-6">
              {/* Accommodation Costs */}
              <div>
                <h3 className="text-lg font-semibold text-gray-800 mb-3">Accommodation</h3>
                <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
                  <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-gray-200">
                      <thead className="bg-gray-50">
                        <tr>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Hotel
                          </th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Price per Night
                          </th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Nights
                          </th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Total
                          </th>
                        </tr>
                      </thead>
                      <tbody className="bg-white divide-y divide-gray-200">
                        {tripPlan.hotels.map((hotel) => (
                          <tr key={hotel.id}>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="text-sm font-medium text-gray-900">{hotel.name}</div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="text-sm text-gray-500">{formatCost(hotel.pricePerNight)}</div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="text-sm text-gray-500">{totalDays}</div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="text-sm font-medium text-indigo-700">
                                {formatCost(hotel.pricePerNight * totalDays)}
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
              
              {/* Attraction Costs */}
              <div>
                <h3 className="text-lg font-semibold text-gray-800 mb-3">Attractions & Activities</h3>
                <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
                  <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-gray-200">
                      <thead className="bg-gray-50">
                        <tr>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Attraction
                          </th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Day
                          </th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Duration
                          </th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Cost
                          </th>
                        </tr>
                      </thead>
                      <tbody className="bg-white divide-y divide-gray-200">
                        {tripPlan.itinerary.flatMap(day => 
                          day.attractions.map(attraction => (
                            <tr key={`${day.day}-${attraction.id}`}>
                              <td className="px-6 py-4 whitespace-nowrap">
                                <div className="text-sm font-medium text-gray-900">{attraction.name}</div>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap">
                                <div className="text-sm text-gray-500">Day {day.day}</div>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap">
                                <div className="text-sm text-gray-500">{attraction.duration}</div>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap">
                                <div className="text-sm font-medium text-indigo-700">{formatCost(attraction.cost)}</div>
                              </td>
                            </tr>
                          ))
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
              
              {/* Other Costs */}
              <div>
                <h3 className="text-lg font-semibold text-gray-800 mb-3">Other Expenses</h3>
                <div className="bg-white rounded-lg border border-gray-200 p-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="p-4 bg-gray-50 rounded-lg">
                      <div className="flex justify-between items-center">
                        <h4 className="font-medium text-gray-800">Meals</h4>
                        <span className="text-indigo-700 font-medium">
                          {formatCost(tripPlan.totalCost * 0.2)}
                        </span>
                      </div>
                      <p className="text-sm text-gray-600 mt-1">Estimated cost for all meals not included in hotel stays</p>
                    </div>
                    
                    <div className="p-4 bg-gray-50 rounded-lg">
                      <div className="flex justify-between items-center">
                        <h4 className="font-medium text-gray-800">Transportation</h4>
                        <span className="text-indigo-700 font-medium">
                          {formatCost(tripPlan.totalCost * 0.1)}
                        </span>
                      </div>
                      <p className="text-sm text-gray-600 mt-1">Local transportation costs during your stay</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ItineraryDetail;
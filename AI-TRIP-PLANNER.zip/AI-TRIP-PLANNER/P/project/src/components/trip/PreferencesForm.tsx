import React, { useState } from 'react';
import { useTrip, BudgetLevel, GroupType } from '../../context/TripContext';
import { Calendar, DollarSign, Users, ArrowLeft, ArrowRight, Star } from 'lucide-react';

const PreferencesForm: React.FC = () => {
  const { 
    destination, 
    budget, 
    setBudget, 
    groupType, 
    setGroupType, 
    startDate, 
    setStartDate, 
    endDate, 
    setEndDate,
    generateTripPlan,
    step,
    setStep, 
    loading 
  } = useTrip();
  
  const handleBack = () => {
    setStep(1);
  };

  const handleGeneratePlan = () => {
    generateTripPlan();
    setStep(3);
  };

  // Calculate minimum date (today)
  const today = new Date();
  const minDate = today.toISOString().split('T')[0];
  
  // Calculate minimum end date (start date or today if no start date)
  const calculateMinEndDate = () => {
    if (startDate) {
      return startDate;
    }
    return minDate;
  };

  return (
    <div className="w-full max-w-4xl mx-auto p-4">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-gray-800 mb-2">
          Trip Preferences for {destination}
        </h2>
        <p className="text-gray-600">
          Tell us more about your trip to help us create the perfect itinerary
        </p>
      </div>
      
      <div className="bg-white rounded-xl shadow-lg p-8 transition-all duration-300 hover:shadow-xl">
        {/* Travel Dates */}
        <div className="mb-8">
          <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center">
            <Calendar size={20} className="mr-2 text-indigo-600" />
            Travel Dates
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label htmlFor="start-date" className="block text-sm font-medium text-gray-700 mb-1">
                Start Date
              </label>
              <input
                id="start-date"
                type="date"
                value={startDate}
                min={minDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all duration-200"
              />
            </div>
            
            <div>
              <label htmlFor="end-date" className="block text-sm font-medium text-gray-700 mb-1">
                End Date
              </label>
              <input
                id="end-date"
                type="date"
                value={endDate}
                min={calculateMinEndDate()}
                onChange={(e) => setEndDate(e.target.value)}
                className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all duration-200"
              />
            </div>
          </div>
          
          {startDate && endDate && (
            <div className="mt-2 text-sm text-indigo-600">
              {(() => {
                const start = new Date(startDate);
                const end = new Date(endDate);
                const diffTime = Math.abs(end.getTime() - start.getTime());
                const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
                return `${diffDays} ${diffDays === 1 ? 'day' : 'days'} trip`;
              })()}
            </div>
          )}
        </div>
        
        {/* Budget Level */}
        <div className="mb-8">
          <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center">
            <DollarSign size={20} className="mr-2 text-indigo-600" />
            Budget Level
          </h3>
          
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {(['low', 'moderate', 'high'] as BudgetLevel[]).map((level) => (
              <button
                key={level}
                onClick={() => setBudget(level)}
                className={`
                  p-4 rounded-lg border-2 transition-all duration-200
                  ${budget === level 
                    ? 'border-indigo-600 bg-indigo-50' 
                    : 'border-gray-200 hover:border-indigo-300 hover:bg-indigo-50/50'}
                `}
              >
                <div className="flex items-center justify-center mb-2">
                  {Array.from({ length: level === 'low' ? 1 : level === 'moderate' ? 2 : 3 }).map((_, i) => (
                    <DollarSign key={i} size={18} className="text-indigo-600" />
                  ))}
                </div>
                <h4 className="text-gray-800 font-medium capitalize">{level}</h4>
                <p className="text-sm text-gray-600 mt-1">
                  {level === 'low' 
                    ? 'Budget-friendly options' 
                    : level === 'moderate' 
                      ? 'Mid-range comfort' 
                      : 'Luxury experience'}
                </p>
              </button>
            ))}
          </div>
        </div>
        
        {/* Group Type */}
        <div className="mb-8">
          <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center">
            <Users size={20} className="mr-2 text-indigo-600" />
            Travel Group
          </h3>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
            {(['single', 'couple', 'family', 'friends'] as GroupType[]).map((type) => (
              <button
                key={type}
                onClick={() => setGroupType(type)}
                className={`
                  p-4 rounded-lg border-2 transition-all duration-200
                  ${groupType === type 
                    ? 'border-indigo-600 bg-indigo-50' 
                    : 'border-gray-200 hover:border-indigo-300 hover:bg-indigo-50/50'}
                `}
              >
                <h4 className="text-gray-800 font-medium capitalize">{type}</h4>
              </button>
            ))}
          </div>
        </div>
        
        {/* Buttons */}
        <div className="flex flex-col sm:flex-row sm:justify-between gap-4">
          <button
            onClick={handleBack}
            className="order-2 sm:order-1 flex items-center justify-center px-6 py-3 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
          >
            <ArrowLeft size={20} className="mr-2" />
            Back to Destination
          </button>
          
          <button
            onClick={handleGeneratePlan}
            disabled={!startDate || !endDate || loading}
            className={`
              order-1 sm:order-2 flex items-center justify-center px-6 py-3 rounded-lg
              ${(!startDate || !endDate) 
                ? 'bg-gray-300 text-gray-500 cursor-not-allowed' 
                : loading 
                  ? 'bg-indigo-500 text-white cursor-wait' 
                  : 'bg-indigo-600 text-white hover:bg-indigo-700'}
              transition-colors
            `}
          >
            {loading ? (
              <>
                <svg className="animate-spin -ml-1 mr-2 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Generating Your Plan...
              </>
            ) : (
              <>
                Generate My Trip Plan
                <ArrowRight size={20} className="ml-2" />
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};

export default PreferencesForm;
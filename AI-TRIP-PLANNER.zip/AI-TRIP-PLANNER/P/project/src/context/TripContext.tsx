import React, { createContext, useState, useContext } from 'react';

export type BudgetLevel = 'low' | 'moderate' | 'high';
export type GroupType = 'single' | 'couple' | 'family' | 'friends';

export interface Attraction {
  id: string;
  name: string;
  description: string;
  image: string;
  cost: number;
  duration: string;
}

export interface Hotel {
  id: string;
  name: string;
  description: string;
  image: string;
  pricePerNight: number;
  rating: number;
  amenities: string[];
}

export interface DayPlan {
  day: number;
  attractions: Attraction[];
  meals: {
    breakfast: string;
    lunch: string;
    dinner: string;
  };
  transportation: string;
}

export interface TripPlan {
  destination: string;
  budget: BudgetLevel;
  groupType: GroupType;
  startDate: string;
  endDate: string;
  hotels: Hotel[];
  itinerary: DayPlan[];
  totalCost: number;
}

interface TripContextType {
  destination: string;
  setDestination: (destination: string) => void;
  budget: BudgetLevel;
  setBudget: (budget: BudgetLevel) => void;
  groupType: GroupType;
  setGroupType: (groupType: GroupType) => void;
  startDate: string;
  setStartDate: (date: string) => void;
  endDate: string;
  setEndDate: (date: string) => void;
  tripPlan: TripPlan | null;
  generateTripPlan: () => Promise<void>;
  loading: boolean;
  step: number;
  setStep: (step: number) => void;
}

const TripContext = createContext<TripContextType | undefined>(undefined);

export const useTrip = () => {
  const context = useContext(TripContext);
  if (context === undefined) {
    throw new Error('useTrip must be used within a TripProvider');
  }
  return context;
};

export const TripProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [destination, setDestination] = useState('');
  const [budget, setBudget] = useState<BudgetLevel>('moderate');
  const [groupType, setGroupType] = useState<GroupType>('couple');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [tripPlan, setTripPlan] = useState<TripPlan | null>(null);
  const [loading, setLoading] = useState(false);
  const [step, setStep] = useState(1);

  const generateAttractions = (city: string): Attraction[] => {
    const attractions: { [key: string]: Attraction[] } = {
      'Paris, France': [
        {
          id: 'paris-1',
          name: 'Eiffel Tower',
          description: 'Iconic iron lattice tower on the Champ de Mars',
          image: 'https://images.pexels.com/photos/699466/pexels-photo-699466.jpeg',
          cost: budget === 'low' ? 25 : budget === 'moderate' ? 40 : 60,
          duration: '3 hours'
        },
        {
          id: 'paris-2',
          name: 'Louvre Museum',
          description: 'World\'s largest art museum and historic monument',
          image: 'https://images.pexels.com/photos/2363/france-landmark-lights-night.jpg',
          cost: budget === 'low' ? 20 : budget === 'moderate' ? 30 : 45,
          duration: '4 hours'
        },
        {
          id: 'paris-3',
          name: 'Notre-Dame Cathedral',
          description: 'Medieval Catholic cathedral on the Île de la Cité',
          image: 'https://images.pexels.com/photos/705764/pexels-photo-705764.jpeg',
          cost: 0,
          duration: '2 hours'
        }
      ],
      'Tokyo, Japan': [
        {
          id: 'tokyo-1',
          name: 'Senso-ji Temple',
          description: 'Ancient Buddhist temple in Asakusa',
          image: 'https://images.pexels.com/photos/5169056/pexels-photo-5169056.jpeg',
          cost: 0,
          duration: '2 hours'
        },
        {
          id: 'tokyo-2',
          name: 'Shibuya Crossing',
          description: 'World\'s busiest pedestrian crossing',
          image: 'https://images.pexels.com/photos/2506923/pexels-photo-2506923.jpeg',
          cost: 0,
          duration: '1 hour'
        },
        {
          id: 'tokyo-3',
          name: 'Tokyo Skytree',
          description: 'Tallest tower in Japan with observation decks',
          image: 'https://images.pexels.com/photos/2614818/pexels-photo-2614818.jpeg',
          cost: budget === 'low' ? 20 : budget === 'moderate' ? 30 : 45,
          duration: '3 hours'
        }
      ]
    };

    return attractions[city] || [
      {
        id: 'generic-1',
        name: 'City Center',
        description: 'Explore the historic city center',
        image: 'https://images.pexels.com/photos/1051073/pexels-photo-1051073.jpeg',
        cost: budget === 'low' ? 10 : budget === 'moderate' ? 20 : 30,
        duration: '3 hours'
      },
      {
        id: 'generic-2',
        name: 'Local Museum',
        description: 'Discover local history and culture',
        image: 'https://images.pexels.com/photos/2034335/pexels-photo-2034335.jpeg',
        cost: budget === 'low' ? 15 : budget === 'moderate' ? 25 : 35,
        duration: '2 hours'
      },
      {
        id: 'generic-3',
        name: 'City Park',
        description: 'Relax in the city\'s main park',
        image: 'https://images.pexels.com/photos/1105766/pexels-photo-1105766.jpeg',
        cost: 0,
        duration: '2 hours'
      }
    ];
  };

  const generateHotels = (city: string): Hotel[] => {
    const hotels: { [key: string]: Hotel[] } = {
      'Paris, France': [
        {
          id: 'paris-hotel-1',
          name: budget === 'low' ? 'Cozy Paris Inn' : budget === 'moderate' ? 'Hotel de Seine' : 'Ritz Paris',
          description: 'Located in the heart of Paris with stunning city views',
          image: 'https://images.pexels.com/photos/261102/pexels-photo-261102.jpeg',
          pricePerNight: budget === 'low' ? 100 : budget === 'moderate' ? 250 : 500,
          rating: budget === 'low' ? 3.5 : budget === 'moderate' ? 4 : 5,
          amenities: budget === 'low' 
            ? ['WiFi', 'Air Conditioning'] 
            : budget === 'moderate' 
              ? ['WiFi', 'Pool', 'Restaurant', 'Gym'] 
              : ['WiFi', 'Pool', 'Spa', 'Multiple Restaurants', 'Concierge']
        },
        {
          id: 'paris-hotel-2',
          name: budget === 'low' ? 'Paris Budget Stay' : budget === 'moderate' ? 'Champs-Élysées Plaza' : 'Four Seasons Paris',
          description: 'Comfortable accommodations with excellent service',
          image: 'https://images.pexels.com/photos/164595/pexels-photo-164595.jpeg',
          pricePerNight: budget === 'low' ? 90 : budget === 'moderate' ? 220 : 450,
          rating: budget === 'low' ? 3 : budget === 'moderate' ? 4.2 : 4.8,
          amenities: budget === 'low' 
            ? ['WiFi', 'Breakfast'] 
            : budget === 'moderate' 
              ? ['WiFi', 'Pool', 'Restaurant'] 
              : ['WiFi', 'Pool', 'Spa', 'Fine Dining', 'Butler Service']
        }
      ],
      'Tokyo, Japan': [
        {
          id: 'tokyo-hotel-1',
          name: budget === 'low' ? 'Tokyo Budget Inn' : budget === 'moderate' ? 'Shinjuku Grand Hotel' : 'Park Hyatt Tokyo',
          description: 'Modern accommodation in the heart of Tokyo',
          image: 'https://images.pexels.com/photos/237371/pexels-photo-237371.jpeg',
          pricePerNight: budget === 'low' ? 80 : budget === 'moderate' ? 200 : 400,
          rating: budget === 'low' ? 3.5 : budget === 'moderate' ? 4.2 : 4.9,
          amenities: budget === 'low' 
            ? ['WiFi', 'Air Conditioning'] 
            : budget === 'moderate' 
              ? ['WiFi', 'Restaurant', 'Gym'] 
              : ['WiFi', 'Pool', 'Spa', 'Multiple Restaurants', 'City View']
        },
        {
          id: 'tokyo-hotel-2',
          name: budget === 'low' ? 'Asakusa Economy Hotel' : budget === 'moderate' ? 'Metropolitan Tokyo' : 'Mandarin Oriental Tokyo',
          description: 'Comfortable stay with excellent transportation access',
          image: 'https://images.pexels.com/photos/189296/pexels-photo-189296.jpeg',
          pricePerNight: budget === 'low' ? 75 : budget === 'moderate' ? 180 : 380,
          rating: budget === 'low' ? 3.2 : budget === 'moderate' ? 4 : 4.7,
          amenities: budget === 'low' 
            ? ['WiFi', 'Vending Machine'] 
            : budget === 'moderate' 
              ? ['WiFi', 'Restaurant', 'Laundry'] 
              : ['WiFi', 'Pool', 'Spa', 'Tea Ceremony', 'Airport Transfer']
        }
      ]
    };

    return hotels[city] || [
      {
        id: 'generic-hotel-1',
        name: budget === 'low' ? 'City Budget Hotel' : budget === 'moderate' ? 'Central Comfort Inn' : 'Luxury Grand Hotel',
        description: 'Comfortable accommodation in a convenient location',
        image: 'https://images.pexels.com/photos/261102/pexels-photo-261102.jpeg',
        pricePerNight: budget === 'low' ? 70 : budget === 'moderate' ? 150 : 300,
        rating: budget === 'low' ? 3.5 : budget === 'moderate' ? 4 : 4.8,
        amenities: budget === 'low' 
          ? ['WiFi', 'Air Conditioning'] 
          : budget === 'moderate' 
            ? ['WiFi', 'Pool', 'Restaurant'] 
            : ['WiFi', 'Pool', 'Spa', 'Multiple Restaurants', 'Concierge']
      },
      {
        id: 'generic-hotel-2',
        name: budget === 'low' ? 'Economy Inn' : budget === 'moderate' ? 'City View Hotel' : 'Royal Palace Hotel',
        description: 'Well-located accommodation with great amenities',
        image: 'https://images.pexels.com/photos/164595/pexels-photo-164595.jpeg',
        pricePerNight: budget === 'low' ? 65 : budget === 'moderate' ? 140 : 280,
        rating: budget === 'low' ? 3.2 : budget === 'moderate' ? 4.2 : 4.7,
        amenities: budget === 'low' 
          ? ['WiFi', 'Breakfast'] 
          : budget === 'moderate' 
            ? ['WiFi', 'Restaurant', 'Gym'] 
            : ['WiFi', 'Pool', 'Spa', 'Fine Dining', 'Butler Service']
      }
    ];
  };

  const generateTripPlan = async () => {
    setLoading(true);
    
    try {
      // Calculate trip duration
      const start = new Date(startDate);
      const end = new Date(endDate);
      const daysCount = Math.ceil((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24)) + 1;
      
      // Get attractions and hotels for the destination
      const attractions = generateAttractions(destination);
      const hotels = generateHotels(destination);
      
      // Generate daily itinerary
      const itinerary: DayPlan[] = Array.from({ length: daysCount }, (_, i) => {
        // Rotate through attractions to create variety
        const dayAttractions = attractions.map((attr, index) => ({
          ...attr,
          id: `${attr.id}-day${i+1}`,
          name: attractions[(index + i) % attractions.length].name,
          description: attractions[(index + i) % attractions.length].description,
          image: attractions[(index + i) % attractions.length].image,
          cost: attractions[(index + i) % attractions.length].cost * 
            (groupType === 'single' ? 1 : groupType === 'couple' ? 2 : groupType === 'family' ? 4 : 3)
        }));

        return {
          day: i + 1,
          attractions: dayAttractions,
          meals: {
            breakfast: budget === 'low' ? 'Local café' : budget === 'moderate' ? 'Hotel breakfast buffet' : 'Gourmet breakfast',
            lunch: budget === 'low' ? 'Street food' : budget === 'moderate' ? 'Local restaurant' : 'Fine dining',
            dinner: budget === 'low' ? 'Local eatery' : budget === 'moderate' ? 'Nice restaurant' : 'Michelin-star restaurant'
          },
          transportation: budget === 'low' ? 'Public transport' : budget === 'moderate' ? 'Mix of public transport and taxis' : 'Private car service'
        };
      });

      // Calculate total cost
      const hotelCost = hotels[0].pricePerNight * daysCount;
      const attractionsCost = itinerary.reduce((total, day) => 
        total + day.attractions.reduce((sum, attr) => sum + attr.cost, 0), 0);
      const mealsCost = daysCount * (budget === 'low' ? 30 : budget === 'moderate' ? 80 : 200) *
        (groupType === 'single' ? 1 : groupType === 'couple' ? 2 : groupType === 'family' ? 4 : 3);
      const transportCost = daysCount * (budget === 'low' ? 10 : budget === 'moderate' ? 50 : 200);
      
      const totalCost = hotelCost + attractionsCost + mealsCost + transportCost;

      const newTripPlan: TripPlan = {
        destination,
        budget,
        groupType,
        startDate,
        endDate,
        hotels,
        itinerary,
        totalCost
      };

      setTripPlan(newTripPlan);
      setStep(3);
    } catch (error) {
      console.error('Error generating trip plan:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <TripContext.Provider value={{
      destination,
      setDestination,
      budget,
      setBudget,
      groupType,
      setGroupType,
      startDate,
      setStartDate,
      endDate,
      setEndDate,
      tripPlan,
      generateTripPlan,
      loading,
      step,
      setStep
    }}>
      {children}
    </TripContext.Provider>
  );
};
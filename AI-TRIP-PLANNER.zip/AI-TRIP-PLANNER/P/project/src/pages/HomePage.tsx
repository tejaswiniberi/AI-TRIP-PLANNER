import React from 'react';
import { Link } from 'react-router-dom';
import { MapPin, Calendar, DollarSign, Users, ArrowRight, MessageSquare, GitPullRequest, Clock } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

const HomePage: React.FC = () => {
  const { isAuthenticated } = useAuth();
  
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <div className="relative pt-20 pb-20 sm:pt-24 sm:pb-40 lg:pt-40 lg:pb-48">
        <div className="absolute inset-0 bg-gradient-to-br from-indigo-600/90 to-purple-700/90 z-0">
          <div 
            className="absolute inset-0 bg-[url('https://images.pexels.com/photos/1851481/pexels-photo-1851481.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2')] 
            bg-cover bg-center mix-blend-overlay opacity-50"
          ></div>
        </div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center">
            <h1 className="text-4xl sm:text-5xl md:text-6xl font-extrabold text-white tracking-tight">
              <span className="block">Your AI-Powered</span>
              <span className="block mt-1 sm:mt-2">Travel Companion</span>
            </h1>
            <p className="mt-6 max-w-lg mx-auto text-xl text-indigo-100">
              Plan your perfect trip in minutes. Tell us your preferences, and our AI will create a personalized itinerary just for you.
            </p>
            
            <div className="mt-10 sm:flex sm:justify-center">
              <div className="rounded-md shadow">
                <Link
                  to={isAuthenticated ? "/planner" : "/register"}
                  className="w-full flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium rounded-md text-indigo-600 bg-white hover:bg-indigo-50 md:py-4 md:text-lg md:px-10 transition-colors duration-300"
                >
                  {isAuthenticated ? "Plan Your Trip" : "Get Started"}
                  <ArrowRight size={20} className="ml-2" />
                </Link>
              </div>
              {!isAuthenticated && (
                <div className="mt-3 sm:mt-0 sm:ml-3">
                  <Link
                    to="/login"
                    className="w-full flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium rounded-md text-white bg-indigo-500 bg-opacity-60 hover:bg-opacity-70 md:py-4 md:text-lg md:px-10 transition-all duration-300"
                  >
                    Log In
                  </Link>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
      
      {/* How It Works Section */}
      <div className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">
              How It Works
            </h2>
            <p className="mt-4 text-xl text-gray-600">
              Plan your perfect trip in just a few simple steps
            </p>
          </div>
          
          <div className="grid grid-cols-1 gap-8 md:grid-cols-3">
            <div className="flex flex-col items-center text-center">
              <div className="flex items-center justify-center h-16 w-16 rounded-md bg-indigo-500 text-white mb-4">
                <MapPin size={28} />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Choose Your Destination</h3>
              <p className="text-gray-600">
                Select where you want to go from popular destinations or search for your dream location.
              </p>
            </div>
            
            <div className="flex flex-col items-center text-center">
              <div className="flex items-center justify-center h-16 w-16 rounded-md bg-indigo-500 text-white mb-4">
                <Users size={28} />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Set Your Preferences</h3>
              <p className="text-gray-600">
                Tell us about your budget, travel style, and who you're traveling with.
              </p>
            </div>
            
            <div className="flex flex-col items-center text-center">
              <div className="flex items-center justify-center h-16 w-16 rounded-md bg-indigo-500 text-white mb-4">
                <Calendar size={28} />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Get Your Itinerary</h3>
              <p className="text-gray-600">
                Receive a personalized day-by-day plan with attractions, hotels, and cost estimates.
              </p>
            </div>
          </div>
        </div>
      </div>
      
      {/* Features Section */}
      <div className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">
              Why Choose JourneyAI
            </h2>
            <p className="mt-4 text-xl text-gray-600">
              Features designed to make your travel planning effortless
            </p>
          </div>
          
          <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3">
            <div className="bg-white rounded-xl shadow-md p-6 hover:shadow-lg transition-shadow duration-300">
              <div className="flex items-center justify-center h-12 w-12 rounded-md bg-indigo-100 text-indigo-600 mb-4">
                <Clock size={24} />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Save Time</h3>
              <p className="text-gray-600">
                Create a complete travel plan in minutes instead of hours of research.
              </p>
            </div>
            
            <div className="bg-white rounded-xl shadow-md p-6 hover:shadow-lg transition-shadow duration-300">
              <div className="flex items-center justify-center h-12 w-12 rounded-md bg-indigo-100 text-indigo-600 mb-4">
                <DollarSign size={24} />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Budget-Friendly</h3>
              <p className="text-gray-600">
                Get recommendations that match your budget level, from economy to luxury.
              </p>
            </div>
            
            <div className="bg-white rounded-xl shadow-md p-6 hover:shadow-lg transition-shadow duration-300">
              <div className="flex items-center justify-center h-12 w-12 rounded-md bg-indigo-100 text-indigo-600 mb-4">
                <GitPullRequest size={24} />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Personalized</h3>
              <p className="text-gray-600">
                Receive tailored suggestions based on your preferences and travel style.
              </p>
            </div>
            
            <div className="bg-white rounded-xl shadow-md p-6 hover:shadow-lg transition-shadow duration-300">
              <div className="flex items-center justify-center h-12 w-12 rounded-md bg-indigo-100 text-indigo-600 mb-4">
                <MessageSquare size={24} />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">AI-Powered</h3>
              <p className="text-gray-600">
                Benefit from intelligent recommendations that improve with each use.
              </p>
            </div>
            
            <div className="bg-white rounded-xl shadow-md p-6 hover:shadow-lg transition-shadow duration-300">
              <div className="flex items-center justify-center h-12 w-12 rounded-md bg-indigo-100 text-indigo-600 mb-4">
                <MapPin size={24} />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Local Insights</h3>
              <p className="text-gray-600">
                Discover hidden gems and authentic experiences at your destination.
              </p>
            </div>
            
            <div className="bg-white rounded-xl shadow-md p-6 hover:shadow-lg transition-shadow duration-300">
              <div className="flex items-center justify-center h-12 w-12 rounded-md bg-indigo-100 text-indigo-600 mb-4">
                <Calendar size={24} />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Flexible Planning</h3>
              <p className="text-gray-600">
                Easily adjust your itinerary based on your schedule and preferences.
              </p>
            </div>
          </div>
        </div>
      </div>
      
      {/* CTA Section */}
      <div className="bg-indigo-700">
        <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:py-16 lg:px-8 lg:flex lg:items-center lg:justify-between">
          <h2 className="text-3xl font-extrabold tracking-tight text-white sm:text-4xl">
            <span className="block">Ready to plan your dream trip?</span>
            <span className="block text-indigo-200">Start your journey with JourneyAI today.</span>
          </h2>
          <div className="mt-8 flex lg:mt-0 lg:flex-shrink-0">
            <div className="inline-flex rounded-md shadow">
              <Link
                to={isAuthenticated ? "/planner" : "/register"}
                className="inline-flex items-center justify-center px-5 py-3 border border-transparent text-base font-medium rounded-md text-indigo-600 bg-white hover:bg-indigo-50 transition-colors"
              >
                {isAuthenticated ? "Plan Your Trip" : "Get Started"}
              </Link>
            </div>
          </div>
        </div>
      </div>
      
      {/* Footer */}
      <footer className="bg-gray-800">
        <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <h3 className="text-white text-lg font-semibold mb-4">JourneyAI</h3>
              <p className="text-gray-400">
                Your AI-powered travel companion, making trip planning easy and personalized.
              </p>
            </div>
            
            <div>
              <h3 className="text-white text-lg font-semibold mb-4">Quick Links</h3>
              <ul className="space-y-2">
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">About Us</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Features</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Testimonials</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Contact</a></li>
              </ul>
            </div>
            
            <div>
              <h3 className="text-white text-lg font-semibold mb-4">Legal</h3>
              <ul className="space-y-2">
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Privacy Policy</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Terms of Service</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Cookie Policy</a></li>
              </ul>
            </div>
          </div>
          
          <div className="mt-8 pt-8 border-t border-gray-700">
            <p className="text-gray-400 text-center">
              &copy; {new Date().getFullYear()} JourneyAI. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default HomePage;
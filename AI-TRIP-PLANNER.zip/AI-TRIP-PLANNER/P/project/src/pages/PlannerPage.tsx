import React from 'react';
import { useTrip } from '../context/TripContext';
import DestinationSelector from '../components/trip/DestinationSelector';
import PreferencesForm from '../components/trip/PreferencesForm';
import TripSummary from '../components/trip/TripSummary';

const PlannerPage: React.FC = () => {
  const { step, loading, tripPlan } = useTrip();
  
  return (
    <div className="min-h-screen pt-20 pb-12">
      <div className="max-w-6xl mx-auto">
        {/* Progress Indicator */}
        <div className="mb-8 px-4">
          <div className="flex items-center justify-between max-w-2xl mx-auto">
            <div className="flex flex-col items-center">
              <div className={`h-10 w-10 rounded-full flex items-center justify-center text-white font-semibold ${
                step >= 1 ? 'bg-indigo-600' : 'bg-gray-300'
              }`}>
                1
              </div>
              <span className="text-sm mt-1 text-gray-600">Destination</span>
            </div>
            
            <div className={`h-1 flex-1 mx-2 ${step >= 2 ? 'bg-indigo-600' : 'bg-gray-300'}`}></div>
            
            <div className="flex flex-col items-center">
              <div className={`h-10 w-10 rounded-full flex items-center justify-center text-white font-semibold ${
                step >= 2 ? 'bg-indigo-600' : 'bg-gray-300'
              }`}>
                2
              </div>
              <span className="text-sm mt-1 text-gray-600">Preferences</span>
            </div>
            
            <div className={`h-1 flex-1 mx-2 ${step >= 3 ? 'bg-indigo-600' : 'bg-gray-300'}`}></div>
            
            <div className="flex flex-col items-center">
              <div className={`h-10 w-10 rounded-full flex items-center justify-center text-white font-semibold ${
                step >= 3 ? 'bg-indigo-600' : 'bg-gray-300'
              }`}>
                3
              </div>
              <span className="text-sm mt-1 text-gray-600">Trip Plan</span>
            </div>
          </div>
        </div>
        
        {step === 1 && <DestinationSelector />}
        {step === 2 && <PreferencesForm />}
        {step === 3 && <TripSummary />}
      </div>
    </div>
  );
};

export default PlannerPage;
import React from 'react';
import RegisterForm from '../components/auth/RegisterForm';

const RegisterPage: React.FC = () => {
  return (
    <div className="min-h-screen pt-20 pb-12 flex flex-col items-center justify-center">
      <RegisterForm />
    </div>
  );
};

export default RegisterPage;
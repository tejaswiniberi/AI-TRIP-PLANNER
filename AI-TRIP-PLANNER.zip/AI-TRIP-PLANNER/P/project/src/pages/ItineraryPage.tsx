import React from 'react';
import ItineraryDetail from '../components/trip/ItineraryDetail';

const ItineraryPage: React.FC = () => {
  return (
    <div className="min-h-screen pt-20 pb-12">
      <ItineraryDetail />
    </div>
  );
};

export default ItineraryPage;
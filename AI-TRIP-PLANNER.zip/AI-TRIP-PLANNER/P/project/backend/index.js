const express = require('express');
const connectDB = require('./config/db');
const cors = require('cors');
require('dotenv').config();

const app = express();
connectDB();

app.use(cors());
app.use(express.json());

// Existing route
app.use('/api/auth', require('./routes/authRoutes'));

// ✅ Add this line to enable trip routes
app.use('/api/trips', require('./routes/trips'));

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
